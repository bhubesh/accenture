# Hand-written-text-recognizer
A tool that can segment and recognize hand written letters. Detailed description is provided in the ppt DLCV Mini project presentation.pptx.
The see the model at work, run the display.py and provide as input one of the test images from tes2.png, tes4.png, tes4.png, tes5.png to see the model at work.
